class Translation(object):

      # Start text
      START = "Hi I am a channel auto forward bot. \nMake your own bot now 👉 Source code <a href='https://github.com/GreyMatter658/auto-forward-bot'> \n\n<b>Support Channel and Groups:</b>\n @GreyMatter_bots, @GreyMatters_bots_discussion"             

      #About text
      ABOUT = """
<b>📝 Language:</b> Python 3
<b>🧰 Framework:</b> Pyrogram
<b>👨‍💻 Developer:</b> 𝐀𝐧𝐨𝐧𝐲𝐦𝐨𝐮𝐬
<b>📢 Channel:</b> @GreyMatter_Bots
<b>👥 Group:</b> @GreyMatters_bots_discussion
<b>🌐Source Code:</b> Press Me <a href='https://github.com/greymatter658/auto-forward-bot'> 🥰"""
